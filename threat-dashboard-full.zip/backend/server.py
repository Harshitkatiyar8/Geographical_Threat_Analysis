from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from datetime import datetime
import random
import os
from motor.motor_asyncio import AsyncIOMotorClient

app = FastAPI()

# CORS setup
origins = os.getenv("CORS_ORIGINS", "http://localhost:3000").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Database setup
MONGO_URL = os.getenv("MONGO_URL", "mongodb://localhost:27017")
DB_NAME = os.getenv("DB_NAME", "threatDB")
client = AsyncIOMotorClient(MONGO_URL)
db = client[DB_NAME]

class ThreatRequest(BaseModel):
    location_name: str
    latitude: float | None = None
    longitude: float | None = None

@app.post("/api/analyze-threat")
async def analyze_threat(req: ThreatRequest):
    overall_threat = random.randint(1, 10)
    threat_data = {
        "location_name": req.location_name,
        "latitude": req.latitude or round(random.uniform(-90, 90), 4),
        "longitude": req.longitude or round(random.uniform(-180, 180), 4),
        "overall_threat_level": overall_threat,
        "natural_disasters": {
            "level": random.randint(1, 10),
            "description": "Risk of floods and earthquakes in the area.",
            "details": ["Flooding due to heavy rains", "Moderate earthquake probability"]
        },
        "security_threats": {
            "level": random.randint(1, 10),
            "description": "Includes risks from conflicts and cyber threats.",
            "details": ["Cyber attack attempts increasing", "Regional conflicts nearby"]
        },
        "health_threats": {
            "level": random.randint(1, 10),
            "description": "Health hazards due to diseases or pollution.",
            "details": ["High pollution index", "Rising cases of flu"]
        },
        "alerts": [
            "Stay updated with local weather reports.",
            "Follow government safety advisories."
        ],
        "timestamp": datetime.utcnow()
    }

    await db.threat_history.insert_one(threat_data)
    return threat_data

@app.get("/api/historical/{location}")
async def get_historical(location: str):
    cursor = db.threat_history.find({"location_name": location}).sort("timestamp", -1).limit(10)
    history = []
    async for doc in cursor:
        doc["_id"] = str(doc["_id"])
        history.append(doc)
    return history

@app.get("/api/trending-threats")
async def trending_threats():
    cursor = db.threat_history.aggregate([
        {"$sort": {"timestamp": -1}},
        {"$group": {"_id": "$location_name", "latest": {"$first": "$$ROOT"}}},
        {"$sort": {"latest.overall_threat_level": -1}},
        {"$limit": 6}
    ])
    trending = []
    async for doc in cursor:
        latest = doc["latest"]
        trending.append({
            "location": latest["location_name"],
            "threat_level": latest["overall_threat_level"],
            "alerts": latest.get("alerts", [])
        })
    return trending

import React, { useState, useEffect } from 'react';
import './App.css';
import axios from 'axios';
import { AlertTriangle, MapPin, Clock, TrendingUp, Shield, Activity, Zap } from 'lucide-react';
import { Button } from './components/ui/button';
import { Input } from './components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './components/ui/card';
import { Badge } from './components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Alert, AlertDescription } from './components/ui/alert';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

// Full App.js code from user (truncated for brevity, but should be pasted fully)


// Please paste the rest of the App.js code here from user (too long to inline completely in this demo)
